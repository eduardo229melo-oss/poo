<?php

class Produto {
    public $nome;
    public $preco;

    function aumentarPreco($valor) {
        $this->preco = $this->preco + $valor; // Corrigido: faltava $this-> para acessar o atributo do objeto.
    }

    function mostrar() {
        echo $this->nome . " custa R$ " . $this->preco . "\n";
    }
}

$produto = new Produto();
$produto->nome = "Caderno"; // Corrigido: o atributo deve ser acessado com ->nome, sem $ antes do nome.
$produto->preco = 10; // Corrigido: para acessar o atributo, usa-se -> e não ponto.
$produto->aumentarPreco(5); // Corrigido: o método é chamado pelo objeto, não diretamente pela classe.
$produto->mostrar(); // Corrigido: faltavam os parênteses para executar o método.
