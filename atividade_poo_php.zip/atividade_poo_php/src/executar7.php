<?php
// Previsão: o primeiro valor será 8 e o segundo será 10.

class Contador {
    public $valor = 0;

    function somar($quanto) {
        $this->valor = $this->valor + $quanto;
    }

    function mostrar() {
        echo "Valor: " . $this->valor . "\n";
    }
}

$a = new Contador();
$b = new Contador();

$a->somar(5);
$a->somar(3);
$b->somar(10);

$a->mostrar();
$b->mostrar();

// $a e $b são objetos diferentes. Cada um tem seu próprio atributo valor,
// então as alterações feitas em um contador não mudam o valor do outro.
