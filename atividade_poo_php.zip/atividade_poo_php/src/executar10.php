<?php
// Escolhi modelar uma bicicleta, porque é um objeto do dia a dia com características
// próprias e ações que podem ser representadas por métodos.

class Bicicleta {
    public $marca;
    public $cor;
    public $marchas;

    function trocarMarcha($novaMarcha) {
        $this->marchas = $novaMarcha;
    }

    function pintar($novaCor) {
        $this->cor = $novaCor;
    }

    function mostrar() {
        echo "Marca: " . $this->marca . "\n";
        echo "Cor: " . $this->cor . "\n";
        echo "Marcha atual: " . $this->marchas . "\n\n";
    }
}

$bike1 = new Bicicleta();
$bike1->marca = "Caloi";
$bike1->cor = "azul";
$bike1->marchas = 3;

$bike2 = new Bicicleta();
$bike2->marca = "Monark";
$bike2->cor = "vermelha";
$bike2->marchas = 1;

$bike1->trocarMarcha(5);
$bike2->pintar("preta");

echo "Bicicleta 1\n";
$bike1->mostrar();

echo "Bicicleta 2\n";
$bike2->mostrar();
